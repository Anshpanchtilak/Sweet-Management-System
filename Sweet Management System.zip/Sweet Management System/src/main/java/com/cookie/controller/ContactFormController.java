package com.cookie.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cookie.dto.ContactFormListDTO;
import com.cookie.dto.ContactFormReqDTO;
import com.cookie.dto.ContactFormRespDTO;
import com.cookie.service.ContactFormService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/contact-form")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ContactFormController {
	private final ContactFormService contactFormService; 
	
	@PostMapping("/submit")
    public ResponseEntity<ContactFormRespDTO> submitForm(
            @Valid @RequestBody ContactFormReqDTO dto) {

        ContactFormRespDTO response = contactFormService.submitForm(dto);
        return ResponseEntity.ok(response);
    }
	
	@GetMapping("/lsit")
	public List<ContactFormListDTO> getContactFormList(){
		return contactFormService.getContactFormList();
	}
	
}
