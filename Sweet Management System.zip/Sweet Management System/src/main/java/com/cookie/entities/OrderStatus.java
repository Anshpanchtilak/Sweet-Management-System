package com.cookie.entities;

public enum OrderStatus {
    PENDING,
    SUCCESSFUL,
    CANCELLED
}
