package com.cookie.entities;

public enum Role {
	ADMIN,CUSTOMER;
}
