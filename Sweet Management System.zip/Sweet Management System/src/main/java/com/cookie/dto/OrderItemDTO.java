package com.cookie.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderItemDTO {
    private Long cookieId;
    private int quantity;
}

